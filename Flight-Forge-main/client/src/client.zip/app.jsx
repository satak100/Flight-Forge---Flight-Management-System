import React from 'react';
import {BrowserRouter as Router, Routes, Route} from "react-router-dom";
import Home from './routes/Home';
import {RouteContextProvider} from './context/RouteContext';
import ReviewPage from './routes/ReviewPage';

const App = () => {
    return (
    <RouteContextProvider>
        <div>
            <Router>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/:user_id/review" element={<ReviewPage />} />
                </Routes>
            </Router>
        </div>
    </RouteContextProvider>
    );
    
}
export default App;