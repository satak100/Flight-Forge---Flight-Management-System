import React from 'react';
import Header from '../components/Header';
import SearchRoute from '../components/SearchRoute';
import RouteList from '../components/RouteList';

const Home = () => {
    return (
        <div>
            <Header/>
            <SearchRoute/>
            <RouteList/>
        </div>
    )
}

export default Home;