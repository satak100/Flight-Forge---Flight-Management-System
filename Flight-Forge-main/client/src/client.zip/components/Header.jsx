import React from 'react';

const Header = () => {
  return (
    <div>
        <h1 className="font-weight-light display-1 text-center">
            FlightForge
        </h1>
    </div>
  )
};

export default Header;