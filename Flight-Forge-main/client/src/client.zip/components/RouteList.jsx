import React, {useEffect, useContext} from 'react';
import { RouteContext } from '../context/RouteContext';
import RouteFinder from '../apis/RouteFinder';


const RouteList = (props) => {
    const { Routes, setRoutes, addRoute } = useContext(RouteContext);
    //const { Airports, setAirports } = useContext(AirportContext);
    useEffect(() => {
      const fetchData = async () => {
      try {
          const response1 = await RouteFinder.post("/searchRoute", {
              start_airport_name: 'd',
              end_airport_name: 'b'
          });
          //console.log(response1);
          setRoutes(response1.data.data.Route);

          //const response2 = await RouteFinder.get("/airports");
          //console.log(response2);
          //setAirports(response2);
      } catch (err) {
        console.log("nai");
      }
    };

    fetchData();
    }, []);
    

    return (
        <div className="list-group">
          
          <table id='routeList' className="table table-hover table-dark">
            <thead>
              <tr className="bg-primary">
                <th scope="col">id</th>
                <th scope="col">From (Airport id)</th>
                <th scope="col">To (Airport id)</th>
                <th scope="col">Departure Time</th>
                <th scope="col">Arrival Time</th>
                <th scope="col">Distance (Km)</th>
                <th scope="col">Ticket</th>
              </tr>
            </thead>
            <tbody>
            {Routes &&
                Routes.map((route) => {
                  return (
                    <tr
                      key={route.id}
                    >
                      <td>{route.id}</td>
                      <td>{route.start_airport_id}</td>
                      <td>{route.end_airport_id}</td>
                      <td>{route.departure_time}</td>
                      <td>{route.arrival_time}</td>
                      <td>{route.distance_km}</td>
                      <td>
                        <button
                          className="btn btn-warning"
                        >
                          Buy
                        </button>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      );
};

export default RouteList;