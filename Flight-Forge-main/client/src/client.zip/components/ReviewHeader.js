import React from 'react'

const ReviewHeader = () => {
  return (
    <div>
        <h1 className="font-weight-light display-1 text-center">
            Review
        </h1>
    </div>
  )
}

export default ReviewHeader