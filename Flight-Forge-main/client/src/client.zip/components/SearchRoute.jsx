import React from 'react'
import {useState} from 'react';
import RouteFinder from '../apis/RouteFinder';
import { useContext } from 'react';
import { RouteContext } from '../context/RouteContext';

const SearchRoute = () => {

    const [start_airport, setStart_airport] = useState([]);
    const [end_airport, setEnd_airport] = useState([]);

    const { Routes, setRoutes, addRoute } = useContext(RouteContext);

    const handleSearch = async (e) => {
        e.preventDefault();
        try {
            console.log(start_airport);
            const response1 = await RouteFinder.post("/searchRoute", {
                start_airport_name: start_airport,
                end_airport_name: end_airport
            });
            console.log(response1);
            setRoutes(response1.data.data.Route);
  
            //const response2 = await RouteFinder.get("/airports");
            //console.log(response2);
            //setAirports(response2);
        } catch (err) {
            console.log("nai");
        }
    }

  return (
    <div className='mb-4'>
        <form action="">
            <div className='form-row'>
                <div className='col'>
                    <input type="text" value={start_airport} onChange={e => setStart_airport(e.target.value)} className="form-control" placeholder="From (airport name)"/>
                </div>
                <div className='col'>
                    <input type="text" value={end_airport} onChange={e => setEnd_airport(e.target.value)} className="form-control" placeholder="To (airport name)"/>
                </div>
                <button onClick={handleSearch} className='btn btn-primary'>Find</button>
            </div>
        </form>
    </div>
  )
};

export default SearchRoute;